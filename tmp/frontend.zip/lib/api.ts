export interface ForecastRequest {
  days: number;
  avg_temp: number;
  rainfall: number;
  population_index: number;
  festival: number;
  industrial_index: number;
  heatwave: number;
  population_growth_pct: number;
  industrial_surge_pct: number;
}

export interface ForecastResponse {
  forecast: number[];
  alerts: string[];
  actions: string[];
}

const API_BASE_URL = "http://127.0.0.1:8000";

export async function getForecast(data: ForecastRequest): Promise<ForecastResponse> {
  const response = await fetch(`${API_BASE_URL}/forecast`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.status} ${response.statusText}`);
  }

  return response.json();
}
