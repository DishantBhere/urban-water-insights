export interface RegionData {
  id: string;
  name: string;
  nameHi: string;
  population: number;
  capacity: number;
  industrialLoad: number;
  defaults: {
    population_index: number;
    industrial_index: number;
    rainfall: number;
    avg_temp: number;
  };
}

export const regions: RegionData[] = [
  {
    id: "mumbai",
    name: "Mumbai",
    nameHi: "मुंबई",
    population: 20411000,
    capacity: 3850,
    industrialLoad: 780,
    defaults: {
      population_index: 1.15,
      industrial_index: 1.25,
      rainfall: 8,
      avg_temp: 30,
    },
  },
  {
    id: "delhi",
    name: "Delhi",
    nameHi: "दिल्ली",
    population: 32941000,
    capacity: 4200,
    industrialLoad: 650,
    defaults: {
      population_index: 1.20,
      industrial_index: 1.15,
      rainfall: 2,
      avg_temp: 35,
    },
  },
  {
    id: "bengaluru",
    name: "Bengaluru",
    nameHi: "बेंगलुरु",
    population: 13193000,
    capacity: 2100,
    industrialLoad: 920,
    defaults: {
      population_index: 1.08,
      industrial_index: 1.35,
      rainfall: 5,
      avg_temp: 28,
    },
  },
  {
    id: "chennai",
    name: "Chennai",
    nameHi: "चेन्नई",
    population: 11503000,
    capacity: 1850,
    industrialLoad: 540,
    defaults: {
      population_index: 1.05,
      industrial_index: 1.10,
      rainfall: 4,
      avg_temp: 33,
    },
  },
];
