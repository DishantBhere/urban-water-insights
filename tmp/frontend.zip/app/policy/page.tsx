"use client";

import { useState, useCallback } from "react";
import { useLanguage } from "@/lib/language-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { getForecast, type ForecastRequest, type ForecastResponse } from "@/lib/api";
import {
  Play,
  Loader2,
  AlertTriangle,
  Droplets,
  TrendingDown,
  TrendingUp,
  DollarSign,
  RotateCcw,
  RefreshCw,
  BarChart3,
  SlidersHorizontal,
  Sparkles,
  Users,
  Upload,
  ArrowRight,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface PolicyParams {
  supplyAugmentation: number;
  waterRationing: number;
  priceIncrease: number;
}

interface PolicyImpact {
  shortageReduction: number;
  demandReduction: number;
  demandReductionMLD: number;
  revenueImpact: number;
  revenueChange: number;
  shortageChange: number;
  summary: string;
  publicSentimentRisk: "Low" | "Medium" | "High";
}

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

export default function PolicySimulationPage() {
  const { t } = useLanguage();
  const { toast } = useToast();

  const [scenario] = useState<ForecastRequest>({
    days: 30,
    avg_temp: 32,
    rainfall: 3,
    population_index: 1.05,
    industrial_index: 1.2,
    festival: 0,
    heatwave: 1,
    population_growth_pct: 3,
    industrial_surge_pct: 10,
  });

  const [policy, setPolicy] = useState<PolicyParams>({
    supplyAugmentation: 15,
    waterRationing: 5,
    priceIncrease: 25,
  });

  const [baselineForecast, setBaselineForecast] = useState<ForecastResponse | null>(null);
  const [policyImpact, setPolicyImpact] = useState<PolicyImpact | null>(null);
  const [adjustedForecast, setAdjustedForecast] = useState<number[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"chart" | "data">("chart");
  const [lastSync, setLastSync] = useState<string>("10 mins ago");

  const calculatePolicyImpact = useCallback(
    (forecast: ForecastResponse, policyParams: PolicyParams): PolicyImpact => {
      const supplyEffect = policyParams.supplyAugmentation * 0.8;
      const rationingEffect = policyParams.waterRationing * 0.6;
      const priceEffect = policyParams.priceIncrease * 0.3;

      const shortageReduction = Math.min(supplyEffect + rationingEffect * 0.5, 100);
      const demandReduction = Math.min(rationingEffect + priceEffect, 50);
      const demandReductionMLD = Math.round(demandReduction * 42.5);
      
      const baseRevenue = 10.4;
      const revenueImpact = baseRevenue + (policyParams.priceIncrease * 0.1) - (policyParams.waterRationing * 0.05);
      const revenueChange = (policyParams.priceIncrease * 0.1) - (policyParams.waterRationing * 0.05);

      const shortageChange = shortageReduction * 0.34;

      let publicSentimentRisk: "Low" | "Medium" | "High" = "Low";
      if (policyParams.waterRationing > 15 || policyParams.priceIncrease > 30) {
        publicSentimentRisk = "High";
      } else if (policyParams.waterRationing > 5 || policyParams.priceIncrease > 15) {
        publicSentimentRisk = "Medium";
      }

      const summary = `The current configuration suggests a moderate socio-economic impact. Shortage reduction is projected at ${shortageReduction.toFixed(1)}%, primarily driven by price elasticity in the commercial sector. Public sentiment risk is ${publicSentimentRisk} due to rationing measures.`;

      return {
        shortageReduction,
        demandReduction,
        demandReductionMLD,
        revenueImpact,
        revenueChange,
        shortageChange,
        summary,
        publicSentimentRisk,
      };
    },
    []
  );

  const runPolicySimulation = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const baseline = await getForecast(scenario);
      setBaselineForecast(baseline);

      const impact = calculatePolicyImpact(baseline, policy);
      setPolicyImpact(impact);

      const adjusted = baseline.forecast.map((value) => {
        const reduction = (impact.demandReduction / 100) * value;
        return Math.max(value - reduction, value * 0.7);
      });
      setAdjustedForecast(adjusted);
      setLastSync("Just now");

      toast({
        title: "Simulation Complete",
        description: "Policy impact analysis has been generated.",
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to run simulation";
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [scenario, policy, calculatePolicyImpact, toast]);

  const resetPolicy = () => {
    setPolicy({
      supplyAugmentation: 0,
      waterRationing: 0,
      priceIncrease: 0,
    });
  };

  const exportScenario = () => {
    if (!baselineForecast || !adjustedForecast) {
      toast({
        title: "No Data",
        description: "Run a simulation first to export results.",
        variant: "destructive",
      });
      return;
    }

    const csvContent = [
      ["Month", "Baseline Demand (MLD)", "Simulated Demand (MLD)"].join(","),
      ...MONTHS.map((month, i) => {
        const baselineValue = baselineForecast.forecast[i % baselineForecast.forecast.length] || 0;
        const adjustedValue = adjustedForecast[i % adjustedForecast.length] || 0;
        return [month, baselineValue.toFixed(2), adjustedValue.toFixed(2)].join(",");
      }),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "policy-simulation.csv";
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Complete",
      description: "Policy simulation data has been downloaded.",
    });
  };

  // Generate chart data for 12 months
  const chartData = MONTHS.map((month, index) => {
    const baselineValue = baselineForecast 
      ? baselineForecast.forecast[index % baselineForecast.forecast.length] 
      : 4200 + Math.sin(index * 0.5) * 200;
    const simulatedValue = adjustedForecast 
      ? adjustedForecast[index % adjustedForecast.length]
      : baselineValue * 0.85;
    return {
      month,
      baseline: baselineValue,
      simulated: simulatedValue,
    };
  });

  const confidenceScore = 94.2;

  return (
    <div className="min-h-screen bg-background">
      <div className="px-6 py-4">
        {/* Breadcrumb */}
        <div className="text-sm text-muted-foreground mb-2">
          {t("forecasting")} <span className="mx-2">/</span> <span className="text-foreground">{t("policySimulation")}</span>
        </div>

        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground tracking-tight">
              {t("policySimulation")}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {t("policySubtitle")}. {t("lastSync")}: {lastSync}.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={resetPolicy}
              className="bg-transparent border-border text-foreground hover:bg-muted"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              {t("reset")}
            </Button>
            <Button
              onClick={runPolicySimulation}
              disabled={isLoading}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t("loading")}
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  {t("runSimulation")}
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Error State */}
        {error && (
          <Card className="border-destructive/50 bg-destructive/10 mb-6">
            <CardContent className="flex items-center gap-3 p-4">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              <p className="text-sm text-destructive">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Main Content Grid */}
        <div className="grid grid-cols-12 gap-6">
          {/* Left Sidebar - Parameters */}
          <div className="col-span-12 lg:col-span-3 space-y-6">
            <Card className="bg-card border-border">
              <CardHeader className="pb-4">
                <CardTitle className="text-base font-semibold text-foreground flex items-center justify-between">
                  {t("parameters")}
                  <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Supply Augmentation */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium text-foreground">
                      {t("supplyAugmentation")}
                    </Label>
                    <span className="text-sm font-semibold text-primary">
                      {policy.supplyAugmentation}%
                    </span>
                  </div>
                  <Slider
                    value={[policy.supplyAugmentation]}
                    onValueChange={([value]) => setPolicy((prev) => ({ ...prev, supplyAugmentation: value }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {t("supplyAugmentationDesc")}
                  </p>
                </div>

                {/* Water Rationing */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium text-foreground">
                      {t("waterRationing")}
                    </Label>
                    <span className="text-sm font-semibold text-primary">
                      {policy.waterRationing}%
                    </span>
                  </div>
                  <Slider
                    value={[policy.waterRationing]}
                    onValueChange={([value]) => setPolicy((prev) => ({ ...prev, waterRationing: value }))}
                    max={50}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {t("waterRationingDesc")}
                  </p>
                </div>

                {/* Price Increase */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium text-foreground">
                      {t("priceIncrease")}
                    </Label>
                    <span className="text-sm font-semibold text-primary">
                      {policy.priceIncrease}%
                    </span>
                  </div>
                  <Slider
                    value={[policy.priceIncrease]}
                    onValueChange={([value]) => setPolicy((prev) => ({ ...prev, priceIncrease: value }))}
                    max={50}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {t("priceIncreaseDesc")}
                  </p>
                </div>

                <Button
                  onClick={runPolicySimulation}
                  disabled={isLoading}
                  variant="outline"
                  className="w-full bg-transparent border-primary text-primary hover:bg-primary/10"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t("updateMetrics")}
                </Button>
              </CardContent>
            </Card>

            {/* Policy Outlook Card */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-semibold text-primary uppercase tracking-wider">
                  Policy Outlook
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-foreground leading-relaxed">
                  The current configuration suggests a{" "}
                  <span className="text-primary font-medium">moderate socio-economic impact</span>.
                  {" "}Shortage reduction is projected at {policyImpact?.shortageReduction.toFixed(1) || "12.4"}%, 
                  primarily driven by price elasticity in the commercial sector.
                  {" "}Public sentiment risk is{" "}
                  <span className="text-warning font-medium">{policyImpact?.publicSentimentRisk || "Medium"}</span>
                  {" "}due to rationing measures.
                </p>
                <button className="flex items-center gap-1 text-sm text-primary mt-4 hover:underline">
                  View Full Feasibility Report
                  <ArrowRight className="h-4 w-4" />
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Right Content - KPIs and Chart */}
          <div className="col-span-12 lg:col-span-9 space-y-6">
            {/* KPI Cards Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Shortage Reduction Card */}
              <Card className="bg-card border-border">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <BarChart3 className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      <TrendingUp className="h-3 w-3 text-primary" />
                      <span className="text-primary font-medium">
                        +{policyImpact?.shortageChange.toFixed(1) || "4.2"}%
                      </span>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">
                      Shortage Reduction
                    </p>
                    <p className="text-3xl font-bold text-foreground mt-1">
                      {policyImpact?.shortageReduction.toFixed(1) || "12.4"}%
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Demand Reduction Card */}
              <Card className="bg-card border-border">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Droplets className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      <TrendingDown className="h-3 w-3 text-primary" />
                      <span className="text-primary font-medium">
                        -{policyImpact?.demandReductionMLD || "850"} MLD
                      </span>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">
                      Demand Reduction
                    </p>
                    <p className="text-3xl font-bold text-foreground mt-1">
                      {policyImpact?.demandReduction.toFixed(1) || "18.2"}%
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Revenue Impact Card */}
              <Card className="bg-card border-border">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <DollarSign className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      <TrendingUp className="h-3 w-3 text-primary" />
                      <span className="text-primary font-medium">
                        +${policyImpact?.revenueChange.toFixed(1) || "2.4"}M
                      </span>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">
                      Revenue Impact
                    </p>
                    <p className="text-3xl font-bold text-foreground mt-1">
                      +${policyImpact?.revenueImpact.toFixed(1) || "12.8"}M
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Demand Delta Forecast Chart */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg font-semibold text-foreground">
                      Demand Delta Forecast
                    </CardTitle>
                    <p className="text-xs text-muted-foreground mt-1">
                      Simulated water demand vs. Baseline (Next 12 Months)
                    </p>
                  </div>
                  <div className="flex items-center gap-1 rounded-lg border border-border p-1">
                    <button
                      onClick={() => setViewMode("chart")}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                        viewMode === "chart"
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Chart
                    </button>
                    <button
                      onClick={() => setViewMode("data")}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                        viewMode === "data"
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Data
                    </button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {viewMode === "chart" ? (
                  <div className="h-[320px] mt-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 10%, 20%)" vertical={false} />
                        <XAxis
                          dataKey="month"
                          stroke="hsl(240, 10%, 40%)"
                          tick={{ fill: "hsl(240, 10%, 60%)", fontSize: 11 }}
                          axisLine={false}
                          tickLine={false}
                        />
                        <YAxis
                          stroke="hsl(240, 10%, 40%)"
                          tick={{ fill: "hsl(240, 10%, 60%)", fontSize: 11 }}
                          axisLine={false}
                          tickLine={false}
                          domain={["auto", "auto"]}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(240, 10%, 15%)",
                            border: "1px solid hsl(240, 10%, 25%)",
                            borderRadius: "8px",
                            color: "hsl(240, 10%, 95%)",
                          }}
                          formatter={(value: number, name: string) => [
                            `${value.toFixed(0)} MLD`,
                            name === "baseline" ? "Baseline Demand" : "Simulated Demand",
                          ]}
                        />
                        <Legend
                          align="right"
                          verticalAlign="top"
                          iconType="circle"
                          iconSize={8}
                          wrapperStyle={{ paddingBottom: 20 }}
                          formatter={(value) => (
                            <span className="text-xs text-muted-foreground uppercase tracking-wider">
                              {value === "baseline" ? "Baseline Demand" : "Simulated Demand"}
                            </span>
                          )}
                        />
                        <Line
                          type="monotone"
                          dataKey="baseline"
                          stroke="hsl(240, 10%, 50%)"
                          strokeWidth={2}
                          strokeDasharray="5 5"
                          dot={false}
                          activeDot={{ r: 4, fill: "hsl(240, 10%, 50%)" }}
                        />
                        <Line
                          type="monotone"
                          dataKey="simulated"
                          stroke="hsl(180, 50%, 50%)"
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 4, fill: "hsl(180, 50%, 50%)" }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="mt-4 overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Month</th>
                          <th className="text-right py-3 px-4 text-muted-foreground font-medium">Baseline (MLD)</th>
                          <th className="text-right py-3 px-4 text-muted-foreground font-medium">Simulated (MLD)</th>
                          <th className="text-right py-3 px-4 text-muted-foreground font-medium">Delta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {chartData.map((row) => (
                          <tr key={row.month} className="border-b border-border/50">
                            <td className="py-3 px-4 text-foreground">{row.month}</td>
                            <td className="text-right py-3 px-4 text-muted-foreground">{row.baseline.toFixed(0)}</td>
                            <td className="text-right py-3 px-4 text-primary">{row.simulated.toFixed(0)}</td>
                            <td className="text-right py-3 px-4 text-primary">
                              -{(row.baseline - row.simulated).toFixed(0)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer Bar */}
        <div className="mt-6 flex items-center justify-between py-4 border-t border-border">
          <div className="flex items-center gap-8">
            {/* Confidence Score */}
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
                Confidence Score
              </p>
              <div className="flex items-center gap-3">
                <div className="w-36 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${confidenceScore}%` }}
                  />
                </div>
                <span className="text-sm font-semibold text-primary">{confidenceScore}%</span>
              </div>
            </div>

            {/* Model Engine */}
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
                Model Engine
              </p>
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">Aura-V2 (Hydraulic)</span>
              </div>
            </div>

            {/* Impacted Population */}
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
                Impacted Pop.
              </p>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">1.2M Citizens</span>
              </div>
            </div>
          </div>

          <Button
            onClick={exportScenario}
            variant="outline"
            className="bg-transparent border-border text-foreground hover:bg-muted"
          >
            <Upload className="mr-2 h-4 w-4" />
            Export Scenario
          </Button>
        </div>
      </div>
      <Toaster />
    </div>
  );
}
