"use client";

import { useState, useCallback } from "react";
import { useLanguage } from "@/lib/language-context";
import { ScenarioForm } from "@/components/scenario-form";
import { ForecastChart } from "@/components/forecast-chart";
import { AlertsPanel } from "@/components/alerts-panel";
import { ActionsPanel } from "@/components/actions-panel";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getForecast, type ForecastRequest, type ForecastResponse } from "@/lib/api";
import { Download, Save, GitCompare, Droplets, TrendingUp, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";

const DEFAULT_SCENARIO: ForecastRequest = {
  days: 7,
  avg_temp: 32,
  rainfall: 3,
  population_index: 1.05,
  festival: 1,
  industrial_index: 1.2,
  heatwave: 1,
  population_growth_pct: 3,
  industrial_surge_pct: 10,
};

export default function DashboardPage() {
  const { t } = useLanguage();
  const { toast } = useToast();

  const [scenario, setScenario] = useState<ForecastRequest>(DEFAULT_SCENARIO);
  const [forecastResult, setForecastResult] = useState<ForecastResponse | null>(null);
  const [savedScenario, setSavedScenario] = useState<{
    scenario: ForecastRequest;
    result: ForecastResponse;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showComparison, setShowComparison] = useState(false);

  const runForecast = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await getForecast(scenario);
      setForecastResult(result);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to fetch forecast";
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [scenario, toast]);

  const exportCSV = useCallback(() => {
    if (!forecastResult) return;

    const headers = ["Day", "Forecasted Demand (MLD)"];
    const rows = forecastResult.forecast.map((value, index) => [
      `Day ${index + 1}`,
      value.toFixed(2),
    ]);

    const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `water_demand_forecast_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Complete",
      description: "Forecast data has been downloaded as CSV.",
    });
  }, [forecastResult, toast]);

  const saveScenario = useCallback(() => {
    if (!forecastResult) return;
    setSavedScenario({ scenario: { ...scenario }, result: { ...forecastResult } });
    toast({
      title: t("scenarioSaved"),
      description: "You can now compare this with future forecasts.",
    });
  }, [scenario, forecastResult, toast, t]);

  const toggleComparison = useCallback(() => {
    setShowComparison((prev) => !prev);
  }, []);

  const avgDemand = forecastResult
    ? (forecastResult.forecast.reduce((a, b) => a + b, 0) / forecastResult.forecast.length).toFixed(2)
    : null;
  const peakDemand = forecastResult ? Math.max(...forecastResult.forecast).toFixed(2) : null;

  return (
    <div className="min-h-screen bg-background">
      <div className="flex flex-col lg:flex-row">
        {/* Left Sidebar - Scenario Inputs */}
        <aside className="w-full lg:w-[380px] border-r border-border bg-card p-6 lg:min-h-[calc(100vh-4rem)] overflow-y-auto">
          <ScenarioForm
            scenario={scenario}
            onScenarioChange={setScenario}
            onRunForecast={runForecast}
            isLoading={isLoading}
          />
        </aside>

        {/* Right Content - Forecast Results */}
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="flex flex-col gap-6">
            {/* Header with Actions */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-xl font-semibold text-foreground">{t("forecastResults")}</h2>
              {forecastResult && (
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={exportCSV}
                    className="border-border bg-transparent text-foreground hover:bg-muted"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    {t("exportCSV")}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={saveScenario}
                    className="border-border bg-transparent text-foreground hover:bg-muted"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {t("saveScenario")}
                  </Button>
                  {savedScenario && (
                    <Button
                      variant={showComparison ? "default" : "outline"}
                      size="sm"
                      onClick={toggleComparison}
                      className={showComparison 
                        ? "bg-primary text-primary-foreground" 
                        : "border-border bg-transparent text-foreground hover:bg-muted"
                      }
                    >
                      <GitCompare className="mr-2 h-4 w-4" />
                      {t("compareScenarios")}
                    </Button>
                  )}
                </div>
              )}
            </div>

            {/* Error State */}
            {error && (
              <Card className="border-destructive/50 bg-destructive/10">
                <CardContent className="flex items-center gap-3 p-4">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                  <p className="text-sm text-destructive">{error}</p>
                </CardContent>
              </Card>
            )}

            {/* Stats Cards */}
            {forecastResult && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Droplets className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Avg. Demand</p>
                        <p className="text-xl font-semibold text-foreground">{avgDemand} <span className="text-sm font-normal text-muted-foreground">{t("mld")}</span></p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                        <TrendingUp className="h-5 w-5 text-warning" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Peak Demand</p>
                        <p className="text-xl font-semibold text-foreground">{peakDemand} <span className="text-sm font-normal text-muted-foreground">{t("mld")}</span></p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                        <AlertTriangle className="h-5 w-5 text-destructive" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Active Alerts</p>
                        <p className="text-xl font-semibold text-foreground">{forecastResult.alerts.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Chart Section */}
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                {forecastResult ? (
                  <ForecastChart
                    forecast={forecastResult.forecast}
                    comparisonForecast={showComparison ? savedScenario?.result.forecast : undefined}
                  />
                ) : (
                  <div className="flex h-[350px] items-center justify-center">
                    <div className="text-center">
                      <Droplets className="mx-auto h-12 w-12 text-muted-foreground/50" />
                      <p className="mt-4 text-muted-foreground">
                        Configure scenario parameters and run forecast to see results
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Alerts and Actions - Side by Side */}
            {forecastResult && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <AlertsPanel alerts={forecastResult.alerts} />
                  </CardContent>
                </Card>
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <ActionsPanel actions={forecastResult.actions} />
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </main>
      </div>
      <Toaster />
    </div>
  );
}
