"use client";

import { useState, useCallback, useEffect } from "react";
import { useLanguage } from "@/lib/language-context";
import { RegionSelector } from "@/components/region-selector";
import { ForecastChart } from "@/components/forecast-chart";
import { AlertsPanel } from "@/components/alerts-panel";
import { ActionsPanel } from "@/components/actions-panel";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { regions, type RegionData } from "@/lib/regions";
import { getForecast, type ForecastRequest, type ForecastResponse } from "@/lib/api";
import {
  Users,
  Droplets,
  Factory,
  Play,
  Loader2,
  AlertTriangle,
  Thermometer,
  CloudRain,
  CalendarDays,
  Flame,
  TrendingUp,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";

export default function RegionalPlanningPage() {
  const { language, t } = useLanguage();
  const { toast } = useToast();

  const [selectedRegion, setSelectedRegion] = useState<RegionData>(regions[0]);
  const [scenario, setScenario] = useState<ForecastRequest>({
    days: 7,
    avg_temp: regions[0].defaults.avg_temp,
    rainfall: regions[0].defaults.rainfall,
    population_index: regions[0].defaults.population_index,
    industrial_index: regions[0].defaults.industrial_index,
    festival: 0,
    heatwave: 0,
    population_growth_pct: 3,
    industrial_surge_pct: 5,
  });
  const [forecastResult, setForecastResult] = useState<ForecastResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Update scenario when region changes
  useEffect(() => {
    setScenario((prev) => ({
      ...prev,
      avg_temp: selectedRegion.defaults.avg_temp,
      rainfall: selectedRegion.defaults.rainfall,
      population_index: selectedRegion.defaults.population_index,
      industrial_index: selectedRegion.defaults.industrial_index,
    }));
    setForecastResult(null);
  }, [selectedRegion]);

  const runForecast = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await getForecast(scenario);
      setForecastResult(result);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to fetch forecast";
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [scenario, toast]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return num.toString();
  };

  const avgDemand = forecastResult
    ? (forecastResult.forecast.reduce((a, b) => a + b, 0) / forecastResult.forecast.length).toFixed(2)
    : null;

  return (
    <div className="min-h-screen bg-background">
      <div className="p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-foreground">{t("navRegional")}</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Location-based water demand forecasting and planning
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Region Selection & Overview */}
            <div className="space-y-6">
              {/* Region Selector */}
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <RegionSelector
                    selectedRegion={selectedRegion}
                    onRegionChange={setSelectedRegion}
                  />
                </CardContent>
              </Card>

              {/* Region Overview */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold text-foreground">
                    {t("regionOverview")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center pb-4 border-b border-border">
                    <h3 className="text-2xl font-bold text-foreground">
                      {language === "hi" ? selectedRegion.nameHi : selectedRegion.name}
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-[rgba(0,255,26,1)]" />
                        <span className="text-sm text-muted-foreground">{t("basePopulation")}</span>
                      </div>
                      <span className="font-semibold text-foreground">
                        {formatNumber(selectedRegion.population)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                      <div className="flex items-center gap-2">
                        <Droplets className="h-4 w-4 text-[rgba(0,217,255,1)]" />
                        <span className="text-sm text-muted-foreground">{t("baseCapacity")}</span>
                      </div>
                      <span className="font-semibold text-foreground">
                        {selectedRegion.capacity} {t("mld")}
                      </span>
                    </div>

                    <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                      <div className="flex items-center gap-2">
                        <Factory className="h-4 w-4 text-warning" />
                        <span className="text-sm text-muted-foreground">{t("industrialLoad")}</span>
                      </div>
                      <span className="font-semibold text-foreground">
                        {selectedRegion.industrialLoad} {t("mld")}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Scenario Adjustments */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold text-foreground">
                    {t("scenarioInputs")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                      <CalendarDays className="h-3 w-3" />
                      {t("forecastDays")}
                    </Label>
                    <Select
                      value={scenario.days.toString()}
                      onValueChange={(v) => setScenario((prev) => ({ ...prev, days: parseInt(v) }))}
                    >
                      <SelectTrigger className="bg-input border-border">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7">7 {t("days")}</SelectItem>
                        <SelectItem value="14">14 {t("days")}</SelectItem>
                        <SelectItem value="30">30 {t("days")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Thermometer className="h-3 w-3" />
                        {t("avgTemp")}
                      </Label>
                      <Input
                        type="number"
                        value={scenario.avg_temp}
                        onChange={(e) =>
                          setScenario((prev) => ({ ...prev, avg_temp: parseFloat(e.target.value) || 0 }))
                        }
                        className="bg-input border-border"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                        <CloudRain className="h-3 w-3" />
                        {t("rainfall")}
                      </Label>
                      <Input
                        type="number"
                        value={scenario.rainfall}
                        onChange={(e) =>
                          setScenario((prev) => ({ ...prev, rainfall: parseFloat(e.target.value) || 0 }))
                        }
                        className="bg-input border-border"
                      />
                    </div>
                  </div>

                  <div className="space-y-3 rounded-lg bg-muted/50 p-3">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                        <CalendarDays className="h-3 w-3" />
                        {t("festival")}
                      </Label>
                      <Switch
                        checked={scenario.festival === 1}
                        onCheckedChange={(checked) =>
                          setScenario((prev) => ({ ...prev, festival: checked ? 1 : 0 }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Flame className="h-3 w-3" />
                        {t("heatwave")}
                      </Label>
                      <Switch
                        checked={scenario.heatwave === 1}
                        onCheckedChange={(checked) =>
                          setScenario((prev) => ({ ...prev, heatwave: checked ? 1 : 0 }))
                        }
                      />
                    </div>
                  </div>

                  <Button
                    onClick={runForecast}
                    disabled={isLoading}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t("loading")}
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        {t("runForecast")}
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Forecast Results */}
            <div className="lg:col-span-2 space-y-6">
              {/* Error State */}
              {error && (
                <Card className="border-destructive/50 bg-destructive/10">
                  <CardContent className="flex items-center gap-3 p-4">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                    <p className="text-sm text-destructive">{error}</p>
                  </CardContent>
                </Card>
              )}

              {/* Stats */}
              {forecastResult && (
                <div className="grid grid-cols-3 gap-4">
                  <Card className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Droplets className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Avg. Demand</p>
                          <p className="text-xl font-semibold text-foreground">
                            {avgDemand} <span className="text-sm font-normal text-muted-foreground">{t("mld")}</span>
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                          <TrendingUp className="h-5 w-5 text-warning" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Capacity Gap</p>
                          <p className="text-xl font-semibold text-foreground">
                            {avgDemand ? ((parseFloat(avgDemand) / selectedRegion.capacity) * 100 - 100).toFixed(1) : 0}%
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                          <AlertTriangle className="h-5 w-5 text-destructive" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Alerts</p>
                          <p className="text-xl font-semibold text-foreground">
                            {forecastResult.alerts.length}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Chart */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold">
                    {t("regionalForecast")} - {language === "hi" ? selectedRegion.nameHi : selectedRegion.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {forecastResult ? (
                    <ForecastChart forecast={forecastResult.forecast} />
                  ) : (
                    <div className="flex h-[300px] items-center justify-center">
                      <div className="text-center">
                        <Droplets className="mx-auto h-12 w-12 text-muted-foreground/50" />
                        <p className="mt-4 text-muted-foreground">
                          Select a region and run forecast to see results
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Alerts and Actions */}
              {forecastResult && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-card border-border">
                    <CardContent className="p-4">
                      <AlertsPanel alerts={forecastResult.alerts} />
                    </CardContent>
                  </Card>
                  <Card className="bg-card border-border">
                    <CardContent className="p-4">
                      <ActionsPanel actions={forecastResult.actions} />
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Toaster />
    </div>
  );
}
