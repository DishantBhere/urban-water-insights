"use client";

import { useLanguage } from "@/lib/language-context";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Thermometer,
  CloudRain,
  Users,
  Factory,
  TrendingUp,
  Zap,
  CalendarDays,
  Flame,
  Play,
  Loader2,
} from "lucide-react";
import type { ForecastRequest } from "@/lib/api";

interface ScenarioFormProps {
  scenario: ForecastRequest;
  onScenarioChange: (scenario: ForecastRequest) => void;
  onRunForecast: () => void;
  isLoading: boolean;
}

export function ScenarioForm({
  scenario,
  onScenarioChange,
  onRunForecast,
  isLoading,
}: ScenarioFormProps) {
  const { t } = useLanguage();

  const updateField = (field: keyof ForecastRequest, value: number) => {
    onScenarioChange({ ...scenario, [field]: value });
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">
          {t("scenarioInputs")}
        </h2>
      </div>

      <div className="text-lg text-foreground font-thin font-serif">
        {/* Forecast Period */}
        <div className="space-y-2 font-medium">
          <Label className="text-lg text-foreground font-sans font-normal">
            <CalendarDays className="h-4 w-4" />
            {t("forecastDays")}
          </Label>
          <Select
            value={scenario.days.toString()}
            onValueChange={(v) => updateField("days", parseInt(v))}
          >
            <SelectTrigger className="text-lg text-foreground font-sans font-normal">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">7 {t("days")}</SelectItem>
              <SelectItem value="14">14 {t("days")}</SelectItem>
              <SelectItem value="30">30 {t("days")}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Temperature */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-muted-foreground">
            <Thermometer className="h-4 w-4" />
            {t("avgTemp")} ({t("celsius")})
          </Label>
          <Input
            type="number"
            value={scenario.avg_temp}
            onChange={(e) => updateField("avg_temp", parseFloat(e.target.value) || 0)}
            className="bg-input border-border"
            min={0}
            max={50}
            step={0.5}
          />
        </div>

        {/* Rainfall */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-muted-foreground">
            <CloudRain className="h-4 w-4" />
            {t("rainfall")} ({t("mm")})
          </Label>
          <Input
            type="number"
            value={scenario.rainfall}
            onChange={(e) => updateField("rainfall", parseFloat(e.target.value) || 0)}
            className="bg-input border-border"
            min={0}
            max={100}
            step={0.5}
          />
        </div>

        {/* Population Index */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            {t("populationIndex")}
          </Label>
          <Input
            type="number"
            value={scenario.population_index}
            onChange={(e) => updateField("population_index", parseFloat(e.target.value) || 0)}
            className="bg-input border-border"
            min={0.5}
            max={2}
            step={0.01}
          />
        </div>

        {/* Industrial Index */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-muted-foreground">
            <Factory className="h-4 w-4" />
            {t("industrialIndex")}
          </Label>
          <Input
            type="number"
            value={scenario.industrial_index}
            onChange={(e) => updateField("industrial_index", parseFloat(e.target.value) || 0)}
            className="bg-input border-border"
            min={0.5}
            max={2}
            step={0.01}
          />
        </div>

        {/* Population Growth % */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-muted-foreground">
            <TrendingUp className="h-4 w-4" />
            {t("populationGrowth")}
          </Label>
          <Input
            type="number"
            value={scenario.population_growth_pct}
            onChange={(e) => updateField("population_growth_pct", parseFloat(e.target.value) || 0)}
            className="bg-input border-border"
            min={0}
            max={20}
            step={0.5}
          />
        </div>

        {/* Industrial Surge % */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm text-muted-foreground">
            <Zap className="h-4 w-4" />
            {t("industrialSurge")}
          </Label>
          <Input
            type="number"
            value={scenario.industrial_surge_pct}
            onChange={(e) => updateField("industrial_surge_pct", parseFloat(e.target.value) || 0)}
            className="bg-input border-border"
            min={0}
            max={50}
            step={1}
          />
        </div>

        {/* Toggle Switches */}
        <div className="space-y-4 rounded-lg bg-muted/50 p-4">
          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2 text-sm text-muted-foreground font-sans">
              <CalendarDays className="h-4 w-4 text-[rgba(255,0,166,1)]" />
              {t("festival")}
            </Label>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {scenario.festival ? t("on") : t("off")}
              </span>
              <Switch className="text-[rgba(243,0,0,1)]"
                checked={scenario.festival === 1}
                onCheckedChange={(checked) => updateField("festival", checked ? 1 : 0)}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2 text-sm text-muted-foreground font-sans">
              <Flame className="h-4 w-4 text-[rgba(255,67,0,1)]" />
              {t("heatwave")}
            </Label>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {scenario.heatwave ? t("on") : t("off")}
              </span>
              <Switch
                checked={scenario.heatwave === 1}
                onCheckedChange={(checked) => updateField("heatwave", checked ? 1 : 0)}
              />
            </div>
          </div>
        </div>

        {/* Run Forecast Button */}
        <Button
          onClick={onRunForecast}
          disabled={isLoading}
          className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t("loading")}
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" />
              {t("runForecast")}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
