"use client";

import { useLanguage } from "@/lib/language-context";
import { Lightbulb, CheckCircle2 } from "lucide-react";

interface ActionsPanelProps {
  actions: string[];
}

export function ActionsPanel({ actions }: ActionsPanelProps) {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col gap-3">
      <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
        <Lightbulb className="h-4 w-4 text-info" />
        {t("actions")}
      </h3>
      <div className="space-y-2">
        {actions.length > 0 ? (
          actions.map((action, index) => (
            <div
              key={index}
              className="flex items-start gap-3 rounded-lg bg-info/10 border border-info/20 px-3 py-2 text-sm"
            >
              <Lightbulb className="h-4 w-4 text-info shrink-0 mt-0.5" />
              <span className="text-foreground">{action}</span>
            </div>
          ))
        ) : (
          <div className="flex items-center gap-3 rounded-lg bg-muted px-3 py-2 text-sm">
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">{t("noActions")}</span>
          </div>
        )}
      </div>
    </div>
  );
}
