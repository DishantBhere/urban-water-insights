"use client";

import { useLanguage } from "@/lib/language-context";
import { regions, type RegionData } from "@/lib/regions";
import { cn } from "@/lib/utils";
import { MapPin, Building2 } from "lucide-react";

interface RegionSelectorProps {
  selectedRegion: RegionData;
  onRegionChange: (region: RegionData) => void;
}

export function RegionSelector({ selectedRegion, onRegionChange }: RegionSelectorProps) {
  const { language, t } = useLanguage();

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
        <MapPin className="h-4 w-4 text-primary" />
        {t("selectRegion")}
      </h3>
      <div className="grid grid-cols-2 gap-2">
        {regions.map((region) => {
          const isSelected = region.id === selectedRegion.id;
          return (
            <button
              key={region.id}
              onClick={() => onRegionChange(region)}
              className={cn(
                "flex items-center gap-3 rounded-lg border px-4 py-3 text-left transition-all duration-200",
                isSelected
                  ? "border-primary bg-primary/10 text-foreground"
                  : "border-border bg-card hover:border-primary/50 hover:bg-muted text-muted-foreground"
              )}
            >
              <Building2 className={cn("h-5 w-5", isSelected ? "text-primary" : "text-muted-foreground")} />
              <span className="font-medium">
                {language === "hi" ? region.nameHi : region.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
