"use client";

import { useLanguage } from "@/lib/language-context";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

interface AlertsPanelProps {
  alerts: string[];
}

export function AlertsPanel({ alerts }: AlertsPanelProps) {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col gap-3">
      <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
        <AlertTriangle className="h-4 w-4 text-warning" />
        {t("alerts")}
      </h3>
      <div className="space-y-2">
        {alerts.length > 0 ? (
          alerts.map((alert, index) => (
            <div
              key={index}
              className="flex items-start gap-3 rounded-lg bg-warning/10 border border-warning/20 px-3 py-2 text-sm"
            >
              <AlertTriangle className="h-4 w-4 text-warning shrink-0 mt-0.5" />
              <span className="text-foreground">{alert}</span>
            </div>
          ))
        ) : (
          <div className="flex items-center gap-3 rounded-lg bg-success/10 border border-success/20 px-3 py-2 text-sm">
            <CheckCircle2 className="h-4 w-4 text-success" />
            <span className="text-muted-foreground">{t("noAlerts")}</span>
          </div>
        )}
      </div>
    </div>
  );
}
