"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/lib/language-context";
import { Language } from "@/lib/translations";
import { Droplets, BarChart3, Map, FileText, Search, Bell } from "lucide-react";
import { Input } from "@/components/ui/input";

export function Navigation() {
  const pathname = usePathname();
  const { language, setLanguage, t } = useLanguage();

  const navItems = [
    { href: "/", labelKey: "forecasting", icon: BarChart3 },
    { href: "/policy", labelKey: "simulations", icon: FileText },
    { href: "/regional", labelKey: "infrastructure", icon: Map },
  ];

  const languages: { code: Language; label: string }[] = [
    { code: "en", label: "EN" },
    { code: "hi", label: "HI" },
    { code: "mr", label: "MR" },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur-sm">
      <div className="flex h-14 items-center justify-between px-6">
        <div className="flex items-center gap-8">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Droplets className="h-5 w-5" />
            </div>
            <span className="text-base font-semibold text-foreground hidden sm:block">
              {t("appTitle")}
            </span>
          </Link>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = pathname === item.href || 
                (item.href === "/" && pathname === "/") ||
                (item.href === "/policy" && pathname === "/policy") ||
                (item.href === "/regional" && pathname === "/regional");
              return (
                <Link
                  key={item.href + item.labelKey}
                  href={item.href}
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors rounded-md",
                    isActive
                      ? "text-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {t(item.labelKey)}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          {/* Search Bar */}
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder={t("searchParameters")}
              className="w-56 pl-9 h-9 bg-muted/50 border-border text-sm placeholder:text-muted-foreground"
            />
          </div>

          {/* Notification Bell */}
          <button className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-card text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
            <Bell className="h-4 w-4" />
          </button>

          {/* Language Toggle - EN | HI | MR */}
          <div className="flex items-center rounded-lg border border-border bg-card overflow-hidden">
            {languages.map((lang, index) => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium transition-colors",
                  language === lang.code
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted",
                  index !== languages.length - 1 && "border-r border-border"
                )}
              >
                {lang.label}
              </button>
            ))}
          </div>

          {/* User Avatar */}
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-600 text-amber-100 text-sm font-medium">
            <span>JD</span>
          </div>
        </div>
      </div>

      {/* Mobile navigation */}
      <nav className="flex md:hidden items-center gap-1 px-4 pb-3 overflow-x-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href + item.labelKey}
              href={item.href}
              className={cn(
                "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 whitespace-nowrap",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <Icon className="h-4 w-4" />
              {t(item.labelKey)}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
