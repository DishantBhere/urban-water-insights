"use client";

import { useLanguage } from "@/lib/language-context";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";

interface ForecastChartProps {
  forecast: number[];
  comparisonForecast?: number[];
}

export function ForecastChart({ forecast, comparisonForecast }: ForecastChartProps) {
  const { t } = useLanguage();

  const data = forecast.map((value, index) => ({
    day: `Day ${index + 1}`,
    demand: value,
    comparison: comparisonForecast?.[index],
  }));

  const maxValue = Math.max(
    ...forecast,
    ...(comparisonForecast || []),
  );
  const minValue = Math.min(
    ...forecast,
    ...(comparisonForecast || []),
  );
  const padding = (maxValue - minValue) * 0.1;

  return (
    <div className="h-full w-full">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">
          {t("demandForecast")}
        </h3>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-primary" />
            <span className="text-muted-foreground">{t("currentScenario")}</span>
          </div>
          {comparisonForecast && (
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-chart-3" />
              <span className="text-muted-foreground">{t("savedScenario")}</span>
            </div>
          )}
        </div>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorDemand" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(180, 50%, 50%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(180, 50%, 50%)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorComparison" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(200, 40%, 50%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(200, 40%, 50%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(240, 10%, 20%)" />
            <XAxis
              dataKey="day"
              stroke="hsl(240, 10%, 40%)"
              tick={{ fill: "hsl(240, 10%, 60%)", fontSize: 12 }}
            />
            <YAxis
              domain={[minValue - padding, maxValue + padding]}
              stroke="hsl(240, 10%, 40%)"
              tick={{ fill: "hsl(240, 10%, 60%)", fontSize: 12 }}
              tickFormatter={(value) => `${value.toFixed(0)}`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(240, 10%, 15%)",
                border: "1px solid hsl(240, 10%, 25%)",
                borderRadius: "8px",
                color: "hsl(240, 10%, 95%)",
              }}
              formatter={(value: number) => [`${value.toFixed(2)} ${t("mld")}`, t("demandUnit")]}
            />
            <Area
              type="monotone"
              dataKey="demand"
              stroke="hsl(180, 50%, 50%)"
              strokeWidth={2}
              fill="url(#colorDemand)"
            />
            {comparisonForecast && (
              <Area
                type="monotone"
                dataKey="comparison"
                stroke="hsl(200, 40%, 50%)"
                strokeWidth={2}
                strokeDasharray="5 5"
                fill="url(#colorComparison)"
              />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
